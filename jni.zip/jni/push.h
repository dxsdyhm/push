#pragma once

int push_init();
void push_uninit();